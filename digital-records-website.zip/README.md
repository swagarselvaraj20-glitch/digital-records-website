# Digital Records and Document Management
Educational static website (HTML, CSS, JavaScript). No server, database, login or paid service needed.

## Files
`index.html`, `style.css`, `script.js`, `assets/` (3 SVG illustrations). All paths are relative, so it works at a GitHub Pages project URL.

## Publish on GitHub Pages (free)
1. Sign in or create a free account at https://github.com/
2. Click **+** > **New repository**. Name it `digital-records-website`, choose **Public**, click **Create repository**.
3. Unzip `digital-records-website.zip` on your computer. Open the unzipped folder.
4. In the repository click **uploading an existing file**. Drag in `index.html`, `style.css`, `script.js`, `README.md` and the `assets` folder (upload the real files, not the ZIP). Click **Commit changes**.
5. Go to **Settings > Pages**. Under **Build and deployment**, set Source to **Deploy from a branch**, Branch **main**, folder **/(root)**, then **Save**.
6. Wait 1 to 3 minutes. Refresh Settings > Pages to see your link: `https://YOUR-USERNAME.github.io/digital-records-website/` (replace YOUR-USERNAME with your GitHub username).
7. Open the link and test the navigation, records demo, project board, checklist and mobile view.

## Troubleshooting
- **404:** check the repository is Public, Pages is set to main and /(root), and the URL matches the repository name exactly. Wait a few minutes.
- **Blank page / no CSS / broken images:** `index.html`, `style.css`, `script.js` must be in the repository root, and the `assets` folder must be uploaded with exact lowercase names.
- **Features not working:** open the **Actions** tab to see deployment errors, then hard-refresh (Ctrl+Shift+R).
- **Works locally, not online:** a file is probably missing from the upload.

Created for Educational Purposes. The records demo and project board are local simulations stored in your browser only.
