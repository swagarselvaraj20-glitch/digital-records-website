(function(){
"use strict";
var $=function(s){return document.querySelector(s)};
function h(tag,attrs){var e=document.createElement(tag);attrs=attrs||{};for(var k in attrs){if(k==="text")e.textContent=attrs[k];else if(k==="class")e.className=attrs[k];else e.setAttribute(k,attrs[k]);}
for(var i=2;i<arguments.length;i++){var c=arguments[i];if(c)e.appendChild(typeof c==="string"?document.createTextNode(c):c);}return e;}
function load(key,def){try{var v=localStorage.getItem(key);return v?JSON.parse(v):def;}catch(e){return def;}}
function save(key,val){try{localStorage.setItem(key,JSON.stringify(val));}catch(e){}}
var P={doc:"M7 3h8l4 4v14H7zM15 3v4h4M10 12h6M10 16h6",chart:"M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6",users:"M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3 3-5 6-5s6 2 6 5M17 8a3 3 0 010 6M21 20c0-2-1-3.5-3-4.2",lock:"M6 11h12v9H6zM8 11V8a4 4 0 018 0v3",mail:"M3 6h18v12H3zM3 7l9 6 9-6",form:"M5 4h14v16H5zM8 9h8M8 13h8M8 17h4",img:"M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M16 9h.01",clock:"M12 4a8 8 0 100 16 8 8 0 000-16zM12 8v4l3 2",cloud:"M7 18a4 4 0 010-8 5 5 0 019.5-1A4 4 0 0117 18z",save:"M5 4h12l2 2v14H5zM8 4v5h7V4M8 20v-6h8v6",box:"M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10",chat:"M4 5h16v11H9l-5 4z",cal:"M4 6h16v14H4zM4 10h16M8 3v4M16 3v4",edit:"M4 20l4-1L19 8l-3-3L5 16zM14 7l3 3",globe:"M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",hist:"M4 12a8 8 0 108-8M4 4v5h5M12 8v4l3 2",task:"M5 5h14v14H5zM8 12l3 3 5-6"};
function ico(n){var s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("viewBox","0 0 24 24");s.setAttribute("aria-hidden","true");var p=document.createElementNS("http://www.w3.org/2000/svg","path");p.setAttribute("d",P[n]);s.appendChild(p);return h("div",{class:"ico"},s);}
function card(icon,title,paras,list){var c=h("article",{class:"card"});if(icon)c.appendChild(ico(icon));c.appendChild(h("h3",{text:title}));(paras||[]).forEach(function(t){c.appendChild(h("p",{text:t}));});if(list){var u=h("ul");list.forEach(function(t){u.appendChild(h("li",{text:t}));});c.appendChild(u);}return c;}
function fill(id,items){var el=$(id);if(!el)return;items.forEach(function(i){el.appendChild(i);});}

/* Static content */
fill("#featcards",[["doc","Document Management","Organize and retrieve digital information efficiently."],["chart","Office Productivity","Create documents, spreadsheets, presentations, and schedules."],["users","Team Collaboration","Share information and work together more effectively."],["lock","Digital Security","Protect important information through responsible digital practices."]].map(function(a){return card(a[0],a[1],[a[2]]);}));
fill("#flow",[["CREATE","Write or capture new information."],["ORGANIZE","Use clear names and folders."],["STORE","Keep files in a chosen location, ideally with backups."],["SHARE","Give access to the right people."],["COLLABORATE","Edit, comment and review together."],["PROTECT","Use passwords, permissions and backups."]].map(function(a){return h("li",{},h("b",{text:a[0]}),a[1]);}));
fill("#benefitCards",[["clock","Easy Access","Find information more quickly."],["task","Time Saving","Reduce repetitive manual work."],["box","Better Organization","Keep records structured and easier to manage."],["users","Collaboration","Share information with authorized team members."],["doc","Space Efficiency","Reduce the need for physical paper storage."],["save","Backup and Recovery","Support recovery when suitable backups are configured."]].map(function(a){return card(a[0],a[1],[a[2]]);}));
fill("#typeCards",[["doc","Word Documents","Written files for study and office work.",["Assignments","Reports","Letters","Meeting notes"],"Tools: Microsoft Word, Google Docs"],["doc","PDF Files","Fixed-layout files that look the same on any device.",["Certificates","Official reports","Forms","Reference documents"],"Tools: Adobe Acrobat, Google Drive"],["chart","Spreadsheets","Tables of data with calculations.",["Budgets","Attendance records","Mark sheets","Financial calculations"],"Tools: Microsoft Excel, Google Sheets"],["img","Digital Images","Pictures and graphics stored as files.",["Scanned certificates","Event photographs","Diagrams","Digital illustrations"],""],["mail","Email Records","Messages that document decisions and events.",["Announcements","Meeting invitations","Business correspondence","Important confirmations"],"Tools: Gmail, Microsoft Outlook"],["form","Online Forms","Structured questions that collect responses.",["Registration forms","Feedback forms","Event applications","Surveys"],"Tools: Google Forms, Microsoft Forms"]].map(function(a){var c=card(a[0],a[1],[a[2]],a[3]);if(a[4])c.appendChild(h("p",{class:"muted",text:a[4]}));return c;}));

var TOOLS=[
["Google Workspace","cloud","Online apps for creating, storing and sharing work.","Docs, Sheets, Slides, Drive, Gmail, Calendar, Meet, Forms","A class writes a report together in Google Docs and schedules reviews in Calendar.","Free personal Google accounts have core features; business and extra features need paid Workspace plans.","https://workspace.google.com/"],
["Google Drive","cloud","Cloud file storage and sharing.","Folders, link sharing, permission levels, version history","Store assignment files and share a folder with a teacher.","Free storage is limited; more space is paid.","https://drive.google.com/"],
["Google Sheets","chart","Online spreadsheets.","Formulas, charts, shared editing, comments","Track attendance with a team.","Free with a Google account; advanced business features may need a paid plan.","https://sheets.google.com/"],
["Google Calendar","cal","Scheduling and reminders.","Shared calendars, invitations, reminders","Coordinate meetings and deadlines.","Free with a Google account; some options depend on the organization.","https://calendar.google.com/"],
["Microsoft 365","doc","Office suite and cloud services.","Word, Excel, PowerPoint, OneDrive, Outlook, Teams, SharePoint","A company writes, stores and reviews files in one account.","Most full desktop features need a subscription; limited free web versions exist.","https://www.microsoft.com/microsoft-365"],
["Microsoft Teams","chat","Chat, meetings and file sharing.","Channels, video meetings, shared files","A team meets remotely and shares notes.","Free and paid options exist; features vary by plan.","https://www.microsoft.com/microsoft-teams/"],
["OneDrive","cloud","Cloud storage from Microsoft.","File sharing, sync, version history","Back up and share documents.","Limited free storage; more with paid plans.","https://www.microsoft.com/microsoft-365/onedrive/online-cloud-storage"],
["Microsoft Excel","chart","Spreadsheet application.","Formulas, charts, shared workbooks","Build budgets and mark sheets.","Full desktop app needs a subscription or license; a limited web version is free.","https://www.microsoft.com/microsoft-365/excel"],
["Trello","task","Card-based task boards.","Boards, lists, cards, due dates, checklists","Plan a class project on a board.","Free plan available; advanced features are paid.","https://trello.com/"],
["Asana","task","Work and project tracking.","Tasks, assignees, timelines, deadlines","A team assigns and tracks tasks.","Free plan for small teams; more features are paid.","https://asana.com/"],
["Microsoft Planner","task","Simple task planning in Microsoft 365.","Boards, assignments, progress charts","Manage a team's weekly tasks.","Usually requires a qualifying Microsoft 365 plan.","https://www.microsoft.com/microsoft-365/business/task-management-software"]];
fill("#toolCards",TOOLS.map(function(t){var c=card(t[1],t[0],["Purpose: "+t[2],"Key features: "+t[3],"Example: "+t[4]]);c.appendChild(h("p",{class:"muted",text:"Free vs paid: "+t[5]}));c.appendChild(h("a",{class:"btn sm",href:t[6],target:"_blank",rel:"noopener noreferrer",text:"Visit Official Website"}));return c;}));
fill("#collabCards",[["edit","Real-Time Editing","Supported applications let several users edit one document at the same time."],["users","File Sharing","Authorized users can open shared files, depending on the permissions the owner sets."],["chat","Digital Communication","Email, chat and video meetings help teams stay in touch."],["cal","Team Scheduling","Shared calendars help coordinate meetings and deadlines."],["hist","Feedback and Version History","Comments and version history help teams review changes; availability depends on the app and plan."],["globe","Remote Collaboration","People in different places can work together with an internet connection and the right access."]].map(function(a){return card(a[0],a[1],[a[2]]);}));
var CMP=[["Google Docs","Word processing","Reports and shared writing","Real-time editing, comments, suggestions"],["Microsoft Word","Word processing","Formal documents and layouts","Co-authoring and comments via OneDrive/SharePoint"],["Google Sheets","Spreadsheets","Shared data tracking","Real-time editing, comments"],["Microsoft Excel","Spreadsheets","Complex calculations and analysis","Co-authoring in shared workbooks"],["Google Drive","Cloud file storage","Storing and sharing files","Shared folders, permission levels, version history"],["OneDrive","Cloud file storage","Storing files in a Microsoft account","Sharing links, permissions, version history"],["Google Calendar","Scheduling","Meetings and deadlines","Shared calendars, invitations"],["Microsoft Outlook","Email and calendar","Business email and meetings","Shared calendars, meeting invites"],["Trello","Task boards","Simple visual task tracking","Shared boards, comments, assignments"],["Asana","Project and task management","Team projects with deadlines","Assignments, comments, timelines (plan dependent)"],["Microsoft Planner","Task planning","Teams using Microsoft 365","Shared plans, assignments, progress views"]];
fill("#ctable",CMP.map(function(r){var tr=h("tr");tr.appendChild(h("th",{scope:"row",text:r[0]}));r.slice(1).forEach(function(x){tr.appendChild(h("td",{text:x}));});return tr;}));
var QL=[["Home","#home"],["About","#about"],["Digital Records","#records"],["Productivity Tools","#tools"],["Collaboration","#collaboration"],["Project Management","#projects"],["Comparison","#comparison"],["Security","#security"],["Conclusion","#conclusion"]];
fill("#flinks",QL.map(function(l){return h("li",{},h("a",{href:l[1],text:l[0]}));}));
fill("#olinks",[["Google Workspace","https://workspace.google.com/"],["Microsoft 365","https://www.microsoft.com/microsoft-365"],["Trello","https://trello.com/"],["Asana","https://asana.com/"],["Microsoft Planner","https://www.microsoft.com/microsoft-365/business/task-management-software"]].map(function(l){return h("li",{},h("a",{href:l[1],target:"_blank",rel:"noopener noreferrer",text:l[0]}));}));
$("#yr").textContent=new Date().getFullYear();

/* Navigation */
var burger=$("#burger"),menu=$("#menu");
function setMenu(o){menu.classList.toggle("open",o);burger.setAttribute("aria-expanded",String(o));burger.setAttribute("aria-label",o?"Close menu":"Open menu");}
burger.addEventListener("click",function(){setMenu(!menu.classList.contains("open"));});
menu.addEventListener("click",function(e){if(e.target.tagName==="A")setMenu(false);});
document.addEventListener("keydown",function(e){if(e.key==="Escape")setMenu(false);});
var links=[].slice.call(menu.querySelectorAll("a"));
if("IntersectionObserver" in window){var io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting){links.forEach(function(a){var on=a.getAttribute("href")==="#"+en.target.id;a.classList.toggle("active",on);if(on)a.setAttribute("aria-current","true");else a.removeAttribute("aria-current");});}});},{rootMargin:"-40% 0px -55% 0px"});
QL.forEach(function(l){var s=$(l[1]);if(s)io.observe(s);});}

/* Dialog helpers */
function openDlg(d){if(d.showModal)d.showModal();else d.setAttribute("open","");}
function closeDlg(d){if(d.close)d.close();else d.removeAttribute("open");}
[].forEach.call(document.querySelectorAll("[data-close]"),function(b){b.addEventListener("click",function(){closeDlg($("#"+b.getAttribute("data-close")));});});

/* Records manager */
var SAMPLE=[
{id:1,name:"School_Project_Report.pdf",type:"PDF",cat:"Reports",date:"2026-01-15",desc:"Final report for the school science project."},
{id:2,name:"Student_Attendance.xlsx",type:"Spreadsheet",cat:"Spreadsheets",date:"2026-02-03",desc:"Monthly attendance record for one class."},
{id:3,name:"Meeting_Notes.docx",type:"Word Document",cat:"Reports",date:"2026-02-20",desc:"Notes and action points from the staff meeting."},
{id:4,name:"Presentation_Slides.pptx",type:"Presentation",cat:"Presentations",date:"2026-03-05",desc:"Slides for the annual project presentation."},
{id:5,name:"School_Event_Photos.jpg",type:"Image",cat:"Images",date:"2026-03-18",desc:"Photographs taken at the school sports day."}];
var records=load("dr_records",null);if(!Array.isArray(records))records=SAMPLE.slice();
function saveRecs(){save("dr_records",records);}
function renderRecs(){
var q=$("#rsearch").value.trim().toLowerCase(),f=$("#rfilter").value,list=$("#reclist");list.textContent="";
var shown=records.filter(function(r){var okF=f==="All Documents"||r.cat===f;var okQ=!q||[r.name,r.type,r.cat,r.desc].join(" ").toLowerCase().indexOf(q)>-1;return okF&&okQ;});
shown.forEach(function(r){var b=h("button",{type:"button",class:"btn ghost sm danger","aria-label":"Delete record "+r.name,text:"Delete"});b.addEventListener("click",function(){if(confirm('Delete record "'+r.name+'"? This only removes the demo entry.')){records=records.filter(function(x){return x.id!==r.id;});saveRecs();renderRecs();}});
list.appendChild(h("li",{},h("div",{},h("strong",{text:r.name}),h("div",{},h("span",{class:"tag",text:r.type}),h("span",{class:"tag",text:r.cat}),h("span",{class:"muted",text:r.date})),h("div",{class:"muted",text:r.desc})),b));});
$("#rempty").hidden=shown.length>0;$("#rcount").textContent="Showing "+shown.length+" of "+records.length+" records";}
$("#rsearch").addEventListener("input",renderRecs);$("#rfilter").addEventListener("change",renderRecs);
var rf=$("#recForm");
$("#addRec").addEventListener("click",function(){rf.reset();$("#f_date").value=new Date().toISOString().slice(0,10);["name","type","cat","date","desc"].forEach(function(k){$("#e_"+k).textContent="";});openDlg($("#recDlg"));$("#f_name").focus();});
rf.addEventListener("submit",function(e){e.preventDefault();var ok=true,v={};
[["name","f_name","Enter a file name."],["type","f_type","Choose a file type."],["cat","f_cat","Choose a category."],["date","f_date","Choose a date."],["desc","f_desc","Enter a short description."]].forEach(function(a){var el=$("#"+a[1]);v[a[0]]=el.value.trim();var bad=!v[a[0]];$("#e_"+a[0]).textContent=bad?a[2]:"";el.setAttribute("aria-invalid",bad);if(bad)ok=false;});
if(!ok)return;records.unshift({id:Date.now(),name:v.name,type:v.type,cat:v.cat,date:v.date,desc:v.desc});saveRecs();renderRecs();closeDlg($("#recDlg"));});

/* Project board */
var TS=[{id:"t1",title:"Plan website content",desc:"List pages and topics to cover.",status:"todo",pri:"High"},{id:"t2",title:"Design homepage",desc:"Sketch the layout and colors.",status:"todo",pri:"Medium"},{id:"t3",title:"Create digital records section",desc:"Build the interactive records demo.",status:"doing",pri:"High"},{id:"t4",title:"Review website",desc:"Check links, text and mobile layout.",status:"doing",pri:"Low"},{id:"t5",title:"Prepare presentation",desc:"Write speaking notes for the panel.",status:"done",pri:"Medium"}];
var tasks=load("dr_tasks",null);if(!Array.isArray(tasks))tasks=JSON.parse(JSON.stringify(TS));
var COLS=[["todo","TO DO"],["doing","IN PROGRESS"],["done","COMPLETED"]],editId=null;
function saveTasks(){save("dr_tasks",tasks);}
function move(id,st){tasks.forEach(function(t){if(t.id===id)t.status=st;});saveTasks();renderBoard();}
function renderBoard(){var b=$("#board");b.textContent="";
COLS.forEach(function(c,ci){var col=h("section",{class:"col","aria-label":c[1]});var items=tasks.filter(function(t){return t.status===c[0];});
col.appendChild(h("h4",{text:c[1]+" ("+items.length+")"}));
col.addEventListener("dragover",function(e){e.preventDefault();col.classList.add("over");});col.addEventListener("dragleave",function(){col.classList.remove("over");});
col.addEventListener("drop",function(e){e.preventDefault();col.classList.remove("over");var id=e.dataTransfer.getData("text/plain");if(id)move(id,c[0]);});
items.forEach(function(t){var el=h("article",{class:"task",draggable:"true"});el.addEventListener("dragstart",function(e){e.dataTransfer.setData("text/plain",t.id);});
var row=h("div",{class:"row"});
function btn(label,aria,fn,cls){var x=h("button",{type:"button",class:"btn ghost sm "+(cls||""),"aria-label":aria,text:label});x.addEventListener("click",fn);row.appendChild(x);}
if(ci>0)btn("\u2190 Move","Move "+t.title+" to "+COLS[ci-1][1],function(){move(t.id,COLS[ci-1][0]);});
if(ci<2)btn("Move \u2192","Move "+t.title+" to "+COLS[ci+1][1],function(){move(t.id,COLS[ci+1][0]);});
btn("Edit","Edit task "+t.title,function(){openTask(t);});
btn("Delete","Delete task "+t.title,function(){if(confirm('Delete task "'+t.title+'"?')){tasks=tasks.filter(function(x){return x.id!==t.id;});saveTasks();renderBoard();}},"danger");
el.appendChild(h("h5",{text:t.title}));el.appendChild(h("p",{text:t.desc}));el.appendChild(h("span",{class:"tag "+t.pri,text:"Priority: "+t.pri}));el.appendChild(row);col.appendChild(el);});
if(!items.length)col.appendChild(h("p",{class:"muted",text:"No tasks here yet."}));b.appendChild(col);});}
function openTask(t){editId=t?t.id:null;$("#taskTitle").textContent=t?"Edit Task":"Add Task";$("#t_title").value=t?t.title:"";$("#t_desc").value=t?t.desc:"";$("#t_status").value=t?t.status:"todo";$("#t_pri").value=t?t.pri:"Medium";$("#te_title").textContent="";openDlg($("#taskDlg"));$("#t_title").focus();}
$("#addTask").addEventListener("click",function(){openTask(null);});
$("#taskForm").addEventListener("submit",function(e){e.preventDefault();var title=$("#t_title").value.trim();if(!title){$("#te_title").textContent="Enter a task title.";return;}
var d={title:title,desc:$("#t_desc").value.trim(),status:$("#t_status").value,pri:$("#t_pri").value};
if(editId){tasks.forEach(function(t){if(t.id===editId){t.title=d.title;t.desc=d.desc;t.status=d.status;t.pri=d.pri;}});}else{d.id="t"+Date.now();tasks.push(d);}
saveTasks();renderBoard();closeDlg($("#taskDlg"));});
$("#resetBoard").addEventListener("click",function(){if(confirm("Restore the original sample board? Your changes will be lost.")){tasks=JSON.parse(JSON.stringify(TS));saveTasks();renderBoard();}});

/* Security checklist */
var CK=["Use strong, unique passwords.","Enable multi-factor authentication where available.","Back up important files regularly.","Use clear and consistent file names.","Organize files into appropriate folders.","Review file-sharing permissions.","Give access only to people who need it.","Keep software updated.","Avoid suspicious links and email attachments.","Follow applicable privacy policies and record-retention rules."];
var done=load("dr_checks",[]);if(!Array.isArray(done))done=[];
function renderChecks(){var ul=$("#checks");ul.textContent="";CK.forEach(function(t,i){var cb=h("input",{type:"checkbox",id:"ck"+i});cb.checked=done.indexOf(i)>-1;
cb.addEventListener("change",function(){done=done.filter(function(x){return x!==i;});if(cb.checked)done.push(i);save("dr_checks",done);progress();});
ul.appendChild(h("li",{},h("label",{for:"ck"+i},cb,t)));});progress();}
function progress(){var n=done.length;$("#ptext").textContent=n+" of "+CK.length+" completed";$("#pfill").style.width=(n/CK.length*100)+"%";$("#pbar").setAttribute("aria-valuenow",n);}
$("#resetCheck").addEventListener("click",function(){done=[];save("dr_checks",done);renderChecks();});

renderRecs();renderBoard();renderChecks();
})();
